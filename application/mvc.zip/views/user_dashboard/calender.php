<section class="overlape">
            <div class="block no-padding">
               <div data-velocity="-.1" style="background: url('<?= base_url('assets/images/resource/mslider1.jpg')?>') repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div>
               <!-- PARALLAX BACKGROUND IMAGE -->
               <div class="container fluid">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner-header" style="padding-top: 90px;">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
<section class="dashboardhak">
          <div class="container-fluid">
             <div class="row align-items-center">
                <div class="col-md-12 col-12">
                   <h2 class="breadcrumb-title">Dashboard</h2>
                   <nav aria-label="breadcrumb" class="page-breadcrumb">
                      <ol class="breadcrumb">
                         <li class="breadcrumb-item"><a href="#">Home</a></li>
                         <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                      </ol>
                   </nav>
                </div>
             </div>
          </div>
       </section>

<section class="dashboard-gig">
            <div class="container-fluid display-table">
               <div class="row display-table-row">
               <?php $this->load->view('sidebar');?>
                  <div class="col-md-10 col-sm-11 display-table-cell v-align">
                     <div class="user-dashboard">
                        <div class="row row-sm">
                           <div class="col-xl-12 col-lg-12 col-md-12">
                              <div class="cardak">
                                 <div class="row">
                                    <div class="col-lg-12 col-md-12">
                                       <div id="calendar"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

         </section>

         <!-- calendar modal -->
       <div id="modal-view-event" class="modal modal-top fade calendar-modal">
               <div class="modal-dialog modal-dialog-centered">
                   <div class="modal-content">
                       <div class="modal-body">
                           <h4 class="modal-title"><span class="event-icon"></span><span class="event-title"></span></h4>
                           <div class="event-body"></div>
                       </div>
                       <div class="modal-footer">
                           <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                       </div>
                   </div>
               </div>
           </div>

           <div id="modal-view-event-add" class="modal modal-top fade calendar-modal">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <form id="add-event" method="post" action="<?php echo base_url('user/Dashboard/save_event')?>">
                    <div class="modal-body" style="margin-top: 250px;">
                    <h4>Add Appointment Detail</h4>
                      <div class="form-group">
                        <label>Appointment name</label>
                        <input type="text" class="form-control" name="event_name" id="ename" placeholder="Enter Appointment Name" value="" required>
                      </div>
                      <div class="form-group">
                        <label>Appointment Date</label>
                        <input type='text' class="form-control" name="event_date" id="edate" value="" readonly>
                      </div>
                       <div class="form-group">
                        <label>Start Time</label>
                  <input type="text" name="start_time" id="start_time" class="form-control" value="">
                      </div>
                      <div class="form-group">
                        <label>End Time</label>
                      <input type="text" name="end_time" id="end_time" class="form-control" value="">
                      </div>
                      <div class="form-group">
                        <label>Appointment Description</label>
                        <textarea class="form-control" name="description" id="edesc"></textarea>
                      </div>
                      <div class="form-group">
                        <label>Appointment Color</label>
                        <select class="form-control" name="event_color" id="ecolor" style="height:40px;">
                          <option value="fc-bg-default" selected>fc-bg-default</option>
                          <option value="fc-bg-blue">fc-bg-blue</option>
                          <option value="fc-bg-lightgreen">fc-bg-lightgreen</option>
                          <option value="fc-bg-pinkred">fc-bg-pinkred</option>
                          <option value="fc-bg-deepskyblue">fc-bg-deepskyblue</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Appointment Icon</label>
                        <select class="form-control" name="event_icon" id="eicon" style="height:40px;">
                          <option value="circle">circle</option>
                          <option value="cog">cog</option>
                          <option value="group">group</option>
                          <option value="suitcase">suitcase</option>
                          <option value="calendar">calendar</option>
                        </select>
                      </div>
                  </div>
                    <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" >Save</button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                  </div>
                  </form>
                </div>
              </div>
            </div>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

            <!-- timepicker -->

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css" />


<!--        https://cdnjs.com/libraries/moment.js/-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>

<!--        https://cdnjs.com/libraries/bootstrap-datetimepicker-->
        <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

<!-- end timepicker -->
<script type="text/javascript">
   $('#edate').datepicker({
         autoclose: true,
        todayHighlight: true,
        startDate: new Date()
    });
</script>
  <script type="text/javascript">
       $("#start_time").datetimepicker({
                    format : "HH:mm"
                });
  </script>
   <script type="text/javascript">
       $("#end_time").datetimepicker({
                    format : "HH:mm"
                });
  </script>
