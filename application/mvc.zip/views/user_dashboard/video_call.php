
<section class="overlape">
            <div class="block no-padding">
               <div data-velocity="-.1" style="background: url('<?= base_url('assets/images/resource/mslider1.jpg')?>') repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div>
               <!-- PARALLAX BACKGROUND IMAGE -->
               <div class="container fluid">
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="inner-header" style="padding-top: 90px;">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
<section class="dashboardhak">
          <div class="container-fluid">
             <div class="row align-items-center">
                <div class="col-md-12 col-12">
                   <h2 class="breadcrumb-title">Dashboard</h2>
                   <nav aria-label="breadcrumb" class="page-breadcrumb">
                      <ol class="breadcrumb">
                         <li class="breadcrumb-item"><a href="#">Home</a></li>
                         <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                      </ol>
                   </nav>
                </div>
             </div>
          </div>
       </section>
<section class="dashboard-gig">
           <div class="container-fluid display-table">
              <div class="row display-table-row">
                 <?php $this->load->view('sidebar');?>
                 <div class="col-md-10 col-sm-11 display-table-cell v-align">
                    <div class="user-dashboard">
                       <div class="row row-sm">
                          <div class="col-xl-12 col-lg-12 col-md-12">
                             <div class="cardak">
                                <div class="row">
                                   <div class="col-lg-6 offset-3 col-md-12">
                                      <div class="video-img">
                                          <img src="<?= base_url('assets/images/b11.jpg')?>">
                                          <div class="video-chat">
                                              <img src="<?= base_url('assets/images/err8.jpg')?>">
                                               </div>
                                              <div class="video-icon">
                                                  <ul>
                                                      <li><a href="#"><i class="fa fa-phone"></i></a>
                                                      <li><a href="#"><i class="fa fa-microphone"></i></a></li>
                                                  </ul>
                                              </div>
                                          </div>
                                      </div>

                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>

        </section>
