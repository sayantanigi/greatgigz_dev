<?php $baseUrl = base_url(); ?>
 <section class="overlape">
    <div class="block no-padding">
        <div data-velocity="-.1" style="background: url(<?=$baseUrl; ?>images/resource/mslider1.jpg) repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div>
        <!-- PARALLAX BACKGROUND IMAGE -->
        <div class="container fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-header">
                        <h3>Login</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="block remove-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="account-popup-area signin-popup-box static">
                        <div class="account-popup">
                            <h3>Login</h3>
                            <span>Lorem ipsum dolor sit amet consectetur adipiscing elit odio duis risus at lobortis ullamcorper</span>
                            <span class="text-success f-15"><?=$this->session->flashdata('success');  ?></span>
                            <span class="text-danger f-15"><?=$this->session->flashdata('error');  ?></span>
                            <form action="<?=base_url(); ?>validate" method="post">
                                <div class="cfield">
                                    <input type="text" placeholder="Registered Email Id" name="email" />
                                    <i class="la la-user"></i>
                                </div>
                                <div class="error text-left"><?php echo form_error('email'); ?></div>

                                <div class="cfield">
                                    <input type="password" placeholder="********" name="password" />
                                    <i class="la la-key"></i>
                                </div>
                                <div class="error text-left"><?php echo form_error('password'); ?></div>
                                
                                <p class="remember-label"><input type="checkbox" name="cb" id="cb1" /><label for="cb1">Remember me</label></p>
                                <a href="#" title="">Forgot Password?</a>
                                <button type="submit">Login</button>
                            </form>
                            <div class="extra-login">
                                <span>Or</span>
                                <div class="login-social">
                                    <a class="fb-login" href="#" title=""><i class="fa fa-facebook"></i></a>
                                    <a class="tw-login" href="#" title=""><i class="fa fa-google"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- LOGIN POPUP -->
                </div>
            </div>
        </div>
    </div>
</section>

            