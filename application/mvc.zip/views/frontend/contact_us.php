<section class="overlape">
               <div class="block no-padding">
                   <div data-velocity="-.1" style="background: url('<?= base_url('assets/images/resource/mslider1.jpg')?>') repeat scroll 50% 422.28px transparent;" class="parallax scrolly-invisible no-parallax"></div>
                   <!-- PARALLAX BACKGROUND IMAGE -->
                   <div class="container fluid">
                       <div class="row">
                           <div class="col-lg-12">
                               <div class="inner-header">
                                   <h3>Contact Us</h3>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </section>

           <section>
               <div class="block">
                   <div class="container">
                       <div class="row">
                           <div class="col-lg-4 column">
                               <div class="contact-textinfo style2">
                                   <h3>JobHunt Office</h3>
                                   <ul>
                                       <li><i class="la la-map-marker"></i><span><?php if(!empty($get_data->address)){ echo $get_data->address;} ?></span></li>
                                       <li><i class="la la-phone"></i><span>Call Us : <?php if(!empty($get_data->phone)){ echo $get_data->phone;}?></span></li>
                                       <li><i class="la la-fax"></i><span>Fax : 1-985-518-1388</span></li>
                                       <li><i class="la la-envelope-o"></i><span>Email : <?php if(!empty($get_data->email)){ echo $get_data->email;}?></span></li>
                                   </ul>
                               </div>
                           </div>
                           <div class="col-lg-8 column">
                               <div class="contact-form">
                                   <h3>Keep In Touch</h3>
                                   <span class="text-success f-20"><?=$this->session->flashdata('success');  ?></span>
                           <span class="text-danger f-20"><?=$this->session->flashdata('error');  ?></span>
                                   <form method="post" action="<?= base_url('Home/save_contact')?>">
                                       <div class="row">
                                           <div class="col-lg-12">
                                               <span class="pf-title">Full Name</span>
                                               <div class="pf-field">
                                                   <input type="text" placeholder="Full Name" name="name" id="name" required onkeypress="only_alphabets(event)"/>
                                               </div>
                                           </div>
                                           <div class="col-lg-12">
                                               <span class="pf-title">Email</span>
                                               <div class="pf-field">
                                                   <input type="email" placeholder="Email" name="email" id="email" required/>
                                               </div>
                                           </div>
                                           <div class="col-lg-12">
                                               <span class="pf-title">Subject</span>
                                               <div class="pf-field">
                                                   <input type="text" placeholder="Subject" name="subject" id="subject" required/>
                                               </div>
                                           </div>
                                           <div class="col-lg-12">
                                               <span class="pf-title">Message</span>
                                               <div class="pf-field">
                                                   <textarea name="message" id="message" placeholder="Message"></textarea>
                                               </div>
                                           </div>
                                           <div class="col-lg-12">
                                               <button type="submit">Send</button>
                                           </div>
                                       </div>
                                   </form>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </section>
           <section>
               <div class="block remove-bottom">
                   <iframe
                       src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3451.3433400942886!2d-92.02472478540473!3d30.112987422287425!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x862362f6ab1a6857%3A0xb416dfcf8937671f!2s208%20Rue%20Saint%20Barts%2C%20Youngsville%2C%20LA%2070592%2C%20USA!5e0!3m2!1sen!2sin!4v1630565931873!5m2!1sen!2sin"
                       width="100%"
                       height="400"
                       style="border: 0;"
                       allowfullscreen=""
                       loading="lazy"
                   ></iframe>
               </div>
           </section>
