
<?php
$get_setting=$this->Crud_model->get_single('setting');
?>
<footer>
                <div class="blocknwe">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-3 column">
                                <div class="widget">
                                    <div class="about_widget">
                                        <div class="logo">
                                            <a href="##" title=""><img src="<?=base_url(); ?>assets/images/gig-work01-w.png" alt="" /></a>
                                        </div>
                                        <span>
                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
                                        </span>
                                    </div>
                                    <!-- About Widget -->
                                </div>
                            </div>
                            <div class="col-lg-3 column">
                                <div class="widget">
                                    <h3 class="footer-title">Quick Links</h3>
                                    <div class="link_widgets">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <a href="#" title="">Our Services</a>
                                                <a href="#" title="Employer">Employers</a>
                                               <!--  <a href="#" title="Employees">Employees</a> -->
                                                <a href="#" title="workers">Workers</a>
                                                <a href="<?= base_url('pricing')?>" title="">Pricing</a>
                                            </div>
                                            <!-- <div class="col-lg-6">
                                                <a href="#" title="">Residential</a>
                                                <a href="#" title="">Commercial</a>
                                                <a href="#" title="">Virtual</a>
                                                <a href="#" title="">Services</a>
                                                <a href="<?= base_url('pricing')?>" title="">Pricing</a>
                                            </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 column">
                                <div class="widget">
                                    <h3 class="footer-title">Support Link</h3>
                                    <div class="link_widgets">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <a href="<?= base_url('about-us')?>" title="About us">About Us</a>
                                                <a href="<?= base_url('contact-us')?>" title="Contact us">Contact Us</a>
                                                <a href="<?= base_url('privacy-policy')?>" title="privacy policy">Privacy Policy</a>
                                                <a href="<?= base_url('term-and-conditions')?>" title="Term & condition">Terms & Conditions </a>
                                               <!--  <a href="#" title="">Our Safty</a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 column">
                                <div class="about_widget">
                                    <h3 class="footer-title">Contact Us</h3>
                                    <span><?= $get_setting->address?></span>
                                    <span><?= $get_setting->phone ?></span>
                                    <span><?= $get_setting->email ?></span>
                                    <div class="social">
                                        <a href="#" title=""><i class="fa fa-facebook"></i></a>
                                        <a href="#" title=""><i class="fa fa-twitter"></i></a>
                                        <a href="#" title=""><i class="fa fa-linkedin"></i></a>
                                        <a href="#" title=""><i class="fa fa-pinterest"></i></a>
                                        <a href="#" title=""><i class="fa fa-behance"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bottom-line">
                    <span>Copyright © 2021 GIGWORK.PRO. All rights reserved.</span>
                    <a href="#scrollup" class="scrollup" title=""><i class="la la-arrow-up"></i></a>
                </div>
            </footer>
        </div>

        <div class="account-popup-area signin-popup-box">
            <div class="account-popup">
                <span class="close-popup"><i class="la la-close"></i></span>
                <h3>User Login</h3>
                <span>Click To Login With Demo User</span>
                <div class="select-user">
                    <span>Candidate</span>
                    <span>Employer</span>
                </div>
                <form>
                    <div class="cfield">
                        <input type="text" placeholder="Username" />
                        <i class="la la-user"></i>
                    </div>
                    <div class="cfield">
                        <input type="password" placeholder="********" />
                        <i class="la la-key"></i>
                    </div>
                    <p class="remember-label"><input type="checkbox" name="cb" id="cb1" /><label for="cb1">Remember me</label></p>
                    <a href="#" title="">Forgot Password?</a>
                    <button type="submit">Login</button>
                </form>
                <div class="extra-login">
                    <span>Or</span>
                    <div class="login-social">
                        <a class="fb-login" href="#" title=""><i class="fa fa-facebook"></i></a>
                        <a class="tw-login" href="#" title=""><i class="fa fa-twitter"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- LOGIN POPUP -->

        <div class="account-popup-area signup-popup-box">
            <div class="account-popup">
                <span class="close-popup"><i class="la la-close"></i></span>
                <h3>Sign Up</h3>
                <div class="select-user">
                    <span class="candidate-tab">Candidate</span>
                    <span class="employer-tab">Employer</span>
                </div>
                <form>
                    <div class="cfield">
                        <input type="text" placeholder="Username" name="username" />
                        <i class="la la-user"></i>
                    </div>
                    <div class="cfield">
                        <input type="password" placeholder="********" name="password" />
                        <i class="la la-key"></i>
                    </div>
                    <div class="cfield">
                        <input type="text" placeholder="Email" name="email" />
                        <i class="la la-envelope-o"></i>
                    </div>
                    <div class="dropdown-field">
                        <select data-placeholder="Please Select Specialism" name="service" class="chosen">
                            <option>Web Development</option>
                            <option>Web Designing</option>
                            <option>Art & Culture</option>
                            <option>Reading & Writing</option>
                        </select>
                    </div>
                    <div class="cfield">
                        <input type="text" placeholder="Phone Number" name="mobile" />
                        <i class="la la-phone"></i>
                    </div>
                    <input type="hidden" name="user_type" class="user_type">
                    <button type="submit">Signup</button>
                </form>
                <div class="extra-login">
                    <span>Or</span>
                    <div class="login-social">
                        <a class="fb-login" href="#" title=""><i class="fa fa-facebook"></i></a>
                        <a class="tw-login" href="#" title=""><i class="fa fa-twitter"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- SIGNUP POPUP -->

        <input type="hidden" name="base_url" id="base_url" value="<?= base_url()?>">

          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/modernizr.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/script.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/bootstrap.min.js')?>" type="text/javascript"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.js" type="text/javascript"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js" type="text/javascript"></script>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/js/datepicker.js" type="text/javascript"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/js/i18n/datepicker.en.js" type="text/javascript"></script> -->
        <script src="<?= base_url('assets/js/wow.min.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/slick.min.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/parallax.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/select-chosen.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/jquery.scrollbar.min.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/maps2.js')?>" type="text/javascript"></script>
        <script src="<?= base_url('assets/js/bootstrap-datepicker.js')?>" type="text/javascript"></script>
        <script>
           $(document).ready(function(){
              $('[data-toggle="offcanvas"]').click(function(){
                  $("#navigation").toggleClass("hidden-xs");
              });
           });
        </script>
        <script type="text/javascript">
            jQuery(document).ready(function(){
    // jQuery('.datetimepicker').datepicker({
    //     timepicker: true,
    //     language: 'en',
    //     range: true,
    //     multipleDates: true,
    //         multipleDatesSeparator: " - "
    //   });
    jQuery("#add-event").submit(function(){
      //  alert("Submitted");
        var values = {};
        $.each($('#add-event').serializeArray(), function(i, field) {
            values[field.name] = field.value;
        });
        console.log(
          values
        );
    });
  });

  (function () {
      'use strict';
      // ------------------------------------------------------- //
      // Calendar
      // ------------------------------------------------------ //
      jQuery(function() {
          // page is ready
          jQuery('#calendar').fullCalendar({
              themeSystem: 'bootstrap4',
              // emphasizes business hours
              businessHours: false,
              defaultView: 'month',
              // event dragging & resizing
              editable: true,
              // header
              header: {
                  left: 'title',
                  center: 'month',
                  //center: 'month,agendaWeek,agendaDay',
                  right: 'today prev,next'
              },
              events:'<?= base_url('user/dashboard/get_events') ?>',
              eventRender: function(event, element) {

                  if(event.icon){
                      element.find(".fc-title").prepend("<i class='fa fa-"+event.icon+"'></i>");

                  }
                },
              dayClick: function(date,jsEvent, view) {
                  //alert(date.format()); return false;
                //  var datetime=date.format();
                //  var fetchdatetime=datetime.slice(0, 10)+' '+datetime.slice(11);

                 // var time= moment(date.start).format('h:mm:ss a');
                   var fetchDate = $(this).data("date");
                 //  var fetchdatetime = fetchDate+' '+time;
                  jQuery('#modal-view-event-add').modal();
                  $('#edate').val(fetchDate);
              },
              eventClick: function(event, jsEvent, view) {

                      jQuery('.event-icon').html("<i class='fa fa-"+event.icon+"'></i>");
                      jQuery('.event-title').html(event.title);
                      jQuery('.event-body').html(event.description);
                      jQuery('.eventUrl').attr('href',event.url);
                      jQuery('#modal-view-event').modal();
              },
          })

      });

  })(jQuery);
        </script>

         <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCtg6oeRPEkRL9_CE-us3QdvXjupbgG14A&libraries=places&callback=initMap"
  async defer></script>
      <script type="text/javascript" src="<?= base_url('assets/custom_js/validation.js')?>"></script>


  <script src="<?= base_url();?>dist/assets/notify/notify.min.js"></script>
  <script type="text/javascript">

          $(document).ready(function(){
        var sessionMessage = '<?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>';
        if(sessionMessage==null || sessionMessage=="" ){ return false;}
        $.notify(sessionMessage,{ position:"top right",className: 'success' });//session msg
          });


      </script>
     </body>
  </html>
