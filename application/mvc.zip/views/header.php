
<?php
$get_category=$this->Crud_model->GetData('category','',"status='Active'");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Gigwork || homepage</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="shortcut icon" href="<?=base_url(); ?>dist/assets/img/favicon.png">
        <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/css/bootstrap-grid.css" />
        <link rel="stylesheet" href="<?=base_url(); ?>assets/css/icons.css" />
        <link rel="stylesheet" href="<?=base_url(); ?>assets/css/animate.min.css" />
        <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/css/style.css" />
        <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/css/responsive.css" />
        <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/css/chosen.css" />
        <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/css/colors/colors.css" />
        <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/css/bootstrap.css" />
         <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/css/bootstrap-datepicker.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/css/datepicker.css" /> -->
          <script src="<?=base_url(); ?>assets/js/jquery.min.js" type="text/javascript"></script>
           <link rel="stylesheet" type="text/css" href="<?=base_url(); ?>assets/rating_css.css" />
    </head>
    <body>
        <div class="page-loading">
            <img src="<?=base_url(); ?>assets/images/loader.gif" alt="" />
        </div>

        <div class="theme-layout" id="scrollup">
            <div class="responsive-header">
                <div class="responsive-menubar">
                    <div class="res-logo">
                        <a href="<?=base_url(); ?>home" title=""><img src="<?=base_url(); ?>assets/images/gig-work01-w.png" alt="" /></a>
                    </div>
                    <div class="menu-resaction">
                        <div class="res-openmenu"><img src="<?=base_url(); ?>assets/images/icon.png" alt="" /> Menu</div>
                        <div class="res-closemenu"><img src="<?=base_url(); ?>assets/images/icon2.png" alt="" /> Close</div>
                    </div>
                </div>
                <div class="responsive-opensec">
                    <div class="btn-extars">
                        <?php if(!empty($_SESSION['gigwork']['userId'])){?>
                        <a href="<?= base_url('postjob')?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                           <?php } else{?>
                               <a href="<?= base_url('login')?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                           <?php } ?>
                        <ul class="account-btns">
                          <?php if(!empty($_SESSION['gigwork']['userId'])){?>
                            <li class="signup-popup">
                                   <a href="<?=base_url(); ?>dashboard"><i class="la la-key"></i> My Account</a>
                               </li>
                               <li class="signup-popup">
                                   <a href="<?=base_url(); ?>logout"><i class="la la-external-link-square"></i> Logout</a>
                               </li>

                           <?php } else{?>
                            <li class="signup-popup">
                                <a href="<?=base_url(); ?>/register" title=""><i class="la la-key"></i> Sign Up</a>
                            </li>
                            <li class="signin-popup">
                                <a href="<?= base_url('login')?>" title=""><i class="la la-external-link-square"></i> Login</a>
                            </li>
                             <?php } ?>
                        </ul>
                    </div>
                    <!-- Btn Extras -->
                    <form class="res-search">
                        <input type="text" placeholder="Job title, keywords or company name" />
                        <button type="submit"><i class="la la-search"></i></button>
                    </form>
                    <div class="responsivemenu">
                        <ul>
                            <li class="menu-item-has-children">
                                <a href="#" title="">Our Services</a>
                                <ul>
                                  <?php if(!empty($get_category)){
                                            foreach ($get_category as $row ) {
                                    $get_subcategory=$this->Crud_model->GetData('sub_category','',"category_id='".$row->id."'");
                                               ?>
                                        <li class="menu-item-has-children">
                                            <a href="#" title=""><?= ucfirst($row->category_name)?></a>
                                            <ul>
                                                <?php if(!empty($get_subcategory)){
                                                    foreach ($get_subcategory as $key) {
                                                    ?>
                                                <li><a href="<?= base_url('employees_list/'.base64_encode($key->id))?>"><?= ucfirst($key->sub_category_name)?></a></li>

                                            <?php } } ?>
                                            </ul>
                                        </li>

                                    <?php } }?>

                                </ul>
                            </li>
                            <li class="account-btns">
                                <a href="<?= base_url('ourjobs')?>" title="">Our Jobs</a>
                                <!-- <ul>
                                    <li><a href="employees-list.html" title="">Employees List 1</a></li>
                                    <li><a href="#" title="">Employees List 2</a></li>
                                    <li><a href="#" title="">Employees List 3</a></li>
                                    <li><a href="#" title="">Employees Dashboard</a></li>
                                </ul> -->
                            </li>
                            <li class="menu-item-has-children">
                                <a href="#" title="">Become a GIGWORK Partner</a>
                                <ul>
                                    <li><a href="#" title="">For Employer</a></li>
                                    <li><a href="#" title="">For GIGWORKers</a></li>

                                </ul>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>

            <header class="stick-top forsticky">
                <div class="menu-sec">
                    <div class="container">
                        <div class="logo">
                            <a href="<?=base_url(); ?>home" title="">
                                <img class="hidesticky" src="<?=base_url(); ?>assets/images/gig-work01-w.png" alt="" />
                                <img class="showsticky" src="<?=base_url(); ?>assets/images/gig-work01.jpg" alt="" />
                            </a>
                        </div>
                        <!-- Logo -->
                        <div class="btn-extars">
                            <?php if(!empty($_SESSION['gigwork']['userId'])){?>
                            <a href="<?= base_url('postjob')?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                              <?php } else{?>
                                  <a href="<?= base_url('login')?>" title="" class="post-job-btn"><i class="la la-plus"></i>Post Jobs</a>
                              <?php } ?>
                            <ul class="account-btns">
                            <?php if(!empty($_SESSION['gigwork']['userId'])){?>
                                     <li class="">
                                    <a href="<?=base_url(); ?>dashboard"><i class="la la-key"></i> My Account</a>
                                </li>
                                <li class="">
                                    <a href="<?=base_url(); ?>logout"><i class="la la-external-link-square"></i> Logout</a>
                                </li>

                            <?php } else{?>
                                 <li class="">
                                    <a href="<?=base_url(); ?>register"><i class="la la-key"></i> Sign Up</a>
                                </li>
                                <li class="">
                                    <a href="<?=base_url(); ?>login"><i class="la la-external-link-square"></i> Login</a>
                                </li>
                            <?php } ?>
                            </ul>
                        </div>
                        <!-- Btn Extras -->

                        <nav>
                            <ul>
                                <li class="menu-item-has-children">
                                    <a href="#" title="">Our Services</a>
                                    <ul>
                                      <?php if(!empty($get_category)){
                                            foreach ($get_category as $row ) {
                                    $get_subcategory=$this->Crud_model->GetData('sub_category','',"category_id='".$row->id."'");
                                               ?>
                                        <li class="menu-item-has-children">
                                            <a href="#" title=""><?= ucfirst($row->category_name)?></a>
                                            <ul>
                                                <?php if(!empty($get_subcategory)){
                                                    foreach ($get_subcategory as $key) {
                                                    ?>
                                                <li><a href="<?= base_url('employees_list/'.base64_encode($key->id))?>"><?= ucfirst($key->sub_category_name)?></a></li>

                                            <?php } } ?>
                                            </ul>
                                        </li>

                                    <?php } }?>

                                    </ul>
                                </li>

                                <li class="menu-item-has-children">
                                    <a href="#" title="">Become a GIGWORK Partner</a>
                                    <ul>
                                        <li><a href="#" title="">For Employer</a></li>
                                        <li><a href="#" title="">For GIGWORKers</a></li>
                                    </ul>
                                </li>
                                <li class="">
                                    <a href="<?= base_url('ourjobs')?>" title="">Our Jobs</a>
                                </li>
                            </ul>
                        </nav>
                        <!-- Menus -->
                    </div>
                </div>
            </header>
