<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mymodel');
		$this->load->library('cart');
	}

	// public function reg()
	// {
	// 	$this->form_validation->set_rules('username', 'Username', 'required');
	// 	$this->form_validation->set_rules('user_type', 'User Type', 'required');
	// 	$this->form_validation->set_rules('service', 'Service', 'required');
	// 	$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
	// 	$this->form_validation->set_rules('mobile', 'Phone', 'required|max_length[10]');
	// 	$this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');

	// 	if($this->form_validation->run() == false)
	// 	{
	// 		$this->load->view('header');
	// 		$this->load->view('register');
	// 		$this->load->view('footer');

	// 	}else{
	// 		$username = $this->input->post("username");
	// 		$userType = $this->input->post("user_type");
	// 		$email = $this->input->post("email");
	// 		$mobile = $this->input->post("mobile");
	// 		$service = $this->input->post("service");
	// 		$password = $this->input->post("password");

	// 		$data = array(
	// 			'username' =>$username,
	// 			'userType' =>$userType,
	// 			'email' =>$email,
	// 			'mobile' =>$mobile,
	// 			'serviceType' =>$service,
	// 			'password' => md5($password),
	// 			'created'=>date('Y-m-d H:i:s'),
	// 			'status'=>1

	// 		);

	// 		if($this->Mymodel->insert('users',$data))
	// 		{
	// 			$this->session->set_flashdata('success', 'Registration Successfull !');
	// 			redirect('ulogin');
	// 		}
	// 		else{
	// 			$this->session->set_flashdata('error', 'Failed to Register !');
	// 			redirect('register');
	// 		}


	// 	}
	// }
	public function reg()
	 {

	 	$validate=$this->Crud_model->get_single('users',"mobile='".$_POST['mobile']."'");
	    if(!empty($validate))
	     {
				 $data=array(
				 'result'=>0,
				 'data'=>'phone',
				 );
			 }
			 else{
				$validate=$this->Crud_model->get_single('users',"email='".$_POST['email']."'");
				if(!empty($validate))
			 {
				 $data=array(
				 'result'=>0,
				 'data'=>'email',
				 );
			 }
			 }
			 if(empty($validate))
			 {
		$data=array(
				'username' =>$_POST['username'],
				'userType' =>$_POST['user_type'],
				'email' =>$_POST['email'],
				'mobile' =>$_POST['mobile'],
				'serviceType' =>$_POST['service'],
				'password' => md5($_POST['password']),
				'created'=>date('Y-m-d H:i:s'),
				'status'=>1
			);

		if($this->Mymodel->insert('users',$data))
			{
				$this->session->set_flashdata('success', 'Registration Successfull !');
					$data=array(
	       'result'=>1,
	         'data'=>1,
	      );
			}
			else{
				$this->session->set_flashdata('error', 'Failed to Register !');
				$data=array(
	       'result'=>2,
	         'data'=>2,
	      );
			}

		}
	 echo json_encode($data); exit;

    }

	public function validate_user($pId = null)
	{
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');

		if($this->form_validation->run() == false)
		{
			$this->load->view('header');
			$this->load->view('login');
			$this->load->view('footer');
		}
		else{
			$email = $this->input->post("email");
			$password = $this->input->post("password");
			if($this->Mymodel->check_record($email, $password))
			{
				$this->session->set_flashdata('message', 'Logged in successfully !');
				redirect('home');
			}
			else{
				$this->session->set_flashdata('error', 'Invalid Email or Password !');
				redirect('login');
			}
		}
	}

	public function logout()
    {
    unset($_SESSION['gigwork']);
		$this->session->set_flashdata('msg', 'You have logged out.');
		redirect('login');
    }

    public function change_pass()
    {

    }


}//end controller
